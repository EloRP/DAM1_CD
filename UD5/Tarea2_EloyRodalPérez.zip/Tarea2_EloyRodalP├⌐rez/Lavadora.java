public class Lavadora extends Electrodomestico {
    public double precio;

    public boolean aguaCaliente;

    public Lavadora(double potencia, String marca, double precio, boolean aguaCaliente) {
        this.potencia = potencia;
        this.marca = marca;
        this.precio = precio;
        this.aguaCaliente = aguaCaliente;
    }

    

    public Lavadora(String marca, double potencia) {
        this.marca = marca;
        this.potencia = potencia;
        this.aguaCaliente = false;
    }

    @Override
    public String toString() {
        return "Lavadora [tipo=" + tipo + ", precio=" + precio + ", potencia=" + potencia + ", aguaCaliente="
                + aguaCaliente + ", marca=" + marca + "]";
    }

    public void setAguaCaliente(final boolean aguaCaliente) {
        this.aguaCaliente = aguaCaliente;
    }

    public void setPrecio(final double precio) {
        this.precio = precio;
    }

    public boolean getAguaCaliente() {
        return this.aguaCaliente;
    }

    public double getPrecio() {
        return this.precio;
    }

}
