public class Electrodomestico {
    public String tipo;

    public double potencia;

    public String marca;

    @Override
    public String toString() {
        return "Electrodomestico [Tipo=" + tipo + ", Potencia=" + potencia + ", Marca=" + marca + "]";
    }

    public Electrodomestico(String tipo, double potencia, String marca) {
        this.tipo = tipo;
        this.potencia = potencia;
        this.marca = marca;
    }

    public double getConsumo(final int horas) {
        return this.potencia / horas;
    }

    public double getCosteConsumo(final int horas, final double costeHora) {
        return getConsumo(horas) * costeHora;
    }

    public String getTipo() {
        return this.tipo;
    }

    public double getPotencia() {
        return this.potencia;
    }

    public String getMarca() {
        return this.marca;
    }

    public void setTipo(final String tipo) {
        this.tipo = tipo;
    }

    public void setPotencia(final double potencia) {
        this.potencia = potencia;
    }

    public void setMarca(final String marca) {
        this.marca = marca;
    }

    public Electrodomestico() {
    }

    

}
